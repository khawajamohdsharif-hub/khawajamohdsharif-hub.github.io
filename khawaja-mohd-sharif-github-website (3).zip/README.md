# Khawaja Mohd Sharif — Academic Website

A responsive, static academic/research website designed for GitHub Pages.

## Repository structure

```text
.
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── assets/
│   └── Khawaja_Mohd_Sharif_CV.pdf
└── README.md
```

## Deploy on GitHub Pages

1. Create/open the repository:
   `khawajamohdsharif-hub/khawajamohdsharif`
2. Upload **all files and folders** from this package to the repository root.
3. Commit the files.
4. In GitHub, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select your main branch and `/ (root)`.
7. Save.
8. Your site will normally become available at the GitHub Pages URL shown by GitHub.

## Before publishing

Recommended updates:
- Replace the research-paper placeholders with your real publications, preprints, DOI/arXiv links, and PDFs.
- Add Google Scholar, ORCID, ResearchGate, Scopus, or personal academic-profile links if you have them.
- Replace the suggested bookshelf with books you actually want to recommend.
- Replace the researcher-oriented "Hobbies & Interests" entries with your personal hobbies if desired.
- Add your research code repositories to the Materials section.
- Add a profile photograph if you want a more personal academic homepage.
- Consider adding a `favicon.ico` later.

## Design

The site uses a clean editorial academic style with:
- responsive navigation
- research-focused landing page
- publication/thesis section
- conference timeline
- books/research bookshelf
- teaching and materials area
- CV download
- contact section
- mobile responsive layout
- no build system or framework required

## Source basis

The factual academic information in the initial version was taken from the supplied CV. Suggested content is clearly framed as recommendations or editable placeholders rather than invented publications or achievements.
