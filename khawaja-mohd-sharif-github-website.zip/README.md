# Khawaja Mohd Sharif — Academic Website

Personal academic website for **Khawaja Mohd Sharif**, PhD Research Scholar in the Department of Mathematics at Aligarh Muslim University.

## Research
- Optimization on Riemannian Manifolds
- Hadamard Manifolds
- Multiobjective Optimization
- Optimization Algorithms
- Variational Inequalities
- Nonsmooth Optimization
- Machine Learning and Geometric Optimization

## Publish with GitHub Pages

1. Create a repository named **`khawajamohdsharif-hub.github.io`** under your GitHub account.
2. Upload all files and folders from this project.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Your website will be available at `https://khawajamohdsharif-hub.github.io/`.

## Before publishing

- Put your CV PDF at `assets/CV.pdf`.
- Replace `YOUR_EMAIL@example.com` in `index.html` with your academic email.
- Replace the Google Scholar and ORCID `#` links with your profiles.
- Add your publications and projects as they become available.

No framework or build process is required. The site is plain HTML, CSS and JavaScript and works directly with GitHub Pages.
